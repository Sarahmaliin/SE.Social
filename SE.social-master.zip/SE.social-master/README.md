# SE.social - a social network app

This project was created by Eva Antonsson and Sarah Karlsson as a final project in their education to becoming Frontend developers. 
The app works as a social network built with React, node and Firebase. The app has functions such as login authentication with Google, posting messages and images to a feed where users can like the posts and a chat built with chatengine's API. 

## Libraries to download for the project


#### * material-ui/core
#### * material-ui/icons
#### * react-chat-engine
#### * firebase
#### * react-router-dom
#### * react-dom


### Current state of the app
The app isn't fully done due to a time-limit with the course. We will continue working on the app and future updates will come to it. 